<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Title extends ReadOnlyBase
{
    //
    protected $titles_array = ['Mr', 'Mrs', 'Ms', 'Dr', 'Mx'];
}
